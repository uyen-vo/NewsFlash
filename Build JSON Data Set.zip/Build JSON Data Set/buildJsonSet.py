import glob
import json
import os

working_directory = os.getcwd() + "/*.json"
save_directory = os.getcwd() + "/NewDataSet"
save_file_name = "/jsonDataSet.json"
json_list = []

#Get all .json file names
file_names = glob.glob(working_directory)

#Add each json from all the files to json_list
for fn in file_names:
    json_obj = open(fn, 'r')
    for line in json_obj:
        json_list.append(json.loads(line))

#Create the output directory if it does not exist
if not os.path.exists(save_directory):
    os.makedirs(save_directory)

#Save the new json data set to a json file
with open(save_directory + save_file_name, 'w') as f:
    for j in json_list:
        f.write(json.dumps(j) + "\n")
        