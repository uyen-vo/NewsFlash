---------How to combine a list of Json files into one json file---------

Put "buildJsonSet.py" in the same directory as the json files.
Run the python file. "python buildJsonSet.py"

This will combine all json files in the current directory into one json file.
The new json file, called "jsonDataSet.json", will be created in the directory called "NewDataSet".
This directory will be created in the current working directory.
